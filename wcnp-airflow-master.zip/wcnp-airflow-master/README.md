# wcnp-airflow

Custom Helm Chart to deploy Airflow on WCNP


Refer [airflow-kitt](https://gecgithub01.walmart.com/SupplyChainAnalytics/airflow-kitt) for details on usage



The repo uses the [WCNP](https://wcnp.walmart.com/) KITT tooling to build and publish the airflow helm chart

<a alt="KITT pipeline status" href="https://concord.prod.walmart.com/#/org/strati/project/pipeline/process?meta.repoMetadata=SupplyChainAnalytics%2Fwcnp-airflow&limit=50">![KITT badge](https://kitt-badges.k8s.walmart.com/kittbadge?org=SupplyChainAnalytics&repo=wcnp-airflow)</a> [![Build Status](https://ci.wcnp.walmart.com/buildStatus/icon?job=SupplyChainAnalytics/wcnp-airflow/master)](https://ci.wcnp.walmart.com/job/SupplyChainAnalytics/job/wcnp-airflow/job/master/)
