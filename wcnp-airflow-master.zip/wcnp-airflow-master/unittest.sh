
#!/bin/bash

docker build -t wcnp-airflow-unit-tests:latest .

docker run --rm -it wcnp-airflow-unit-tests:latest
